function back() {
 window.history.back();
}
